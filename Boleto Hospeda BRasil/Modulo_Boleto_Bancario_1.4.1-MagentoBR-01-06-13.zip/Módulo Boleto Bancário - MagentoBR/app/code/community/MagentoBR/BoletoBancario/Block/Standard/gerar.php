<?php
class MagentoBR_BoletoBancario_Block_Standard_Gerar extends Mage_Core_Block_Abstract
 {
    protected function _gerar()
    {
        
		exit("Oooo");
		
    }
 }
