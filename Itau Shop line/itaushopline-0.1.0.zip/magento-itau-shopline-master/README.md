Shopline Itau (Magento)
=====================

Modulo de Pagamento do Itau Shopline para o Magento

Como Usar
=====================

Basta Copiar o conteúdo para a pasta ROOT do seu magento e habilitar o módulo nas configurações de pagamentos.

Autor:
=====================
Daniel Chaves - daniel@danielchaves.com.br

Licença:
=====================
http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)

Testes:
=====================
Esse módulo foi testato na versão  1.7.0.2  do Magento e está totalmente funcional

Alguns Créditos:
=====================

Alan Bueno - http://alanbueno.com.br/
Por me contratar para desenvolver o módulo e permitir que o mesmo seja distribuido por Open Software License (OSL 3.0)

Baseado no projeto de: 

Gabriel Rodrigues Couto - https://github.com/gabrielrcouto/php-itaucripto





